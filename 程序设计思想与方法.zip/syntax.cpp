//demo.h
//顶层分解演示
#ifndif abc
#define abc

#include<iostream>
#include<cmath>
#include<cstdlib>
#include<ctime>
#include<cstring>
using namespace std;

//类模版演示
template <class T>
class demo{
	private:
		T unknown_var;
		int *p；
		const int const_int;
		static int static_int;
		static const int static_const_int = 10; //常量静态成员变量在类内赋初值
		
	public:
		demo(int input, T unknown_value);
		demo(const demo &d);
		~demo();
		static void change_static_var(int static_value);
}

#endif



//demo.cpp
#include "demo.h"
//构造函数演示
template <class T>
demo::demo(int input):const_int(input) //常量只能在初始化列表里赋值
{
	//基本赋值操作演示
	unknown_var = unknown_value;
	char *s = "Hello World!"; //char *s = new char[12]; strcpy(s, "Hello World!");
	char c = cin.get(); //读入一个字符，包括空格
	char *pt = &c, &ref = c;
	char ch[];
	cin.getline(ch, 80, '.'); //读入字符串直到停止标志符或特定长度
	int array[5] = {1, 2, 3, 4, 5};
	p = new int[10];
	for(int i=0; i<10; i++) p[i] = i;
	
	//随机数，switch，do-while演示
	srand(time(NULL));
	do{
		random_int = rand()% 50 + 1; //1~50
		switch(random_int/10){
		case 1: cout << 'a' << endl; break;
		case 2: cout << 'b' << endl; break;
		case 3: cout << 'c' << endl; break;
		case 4: cout << 'd' << endl; break;
		case 5: cout << 'e' << endl; break;
		default: cout << 'f' << endl; break;
		}
	}while(random_int < 30)
	
}

//复制构造函数演示（对于有动态内存分配的函数）
template <class T>
demo::demo(const demo &d):const_int(d.const_int)
{
	unknown_var = d.unknown_var;
	p = new int[10];
	for(int i=0; i<10; i++) p[i] = i;
}

//析构函数演示
template <class T>
demo::~demo()
{
	delete[] p;
}

//静态成员变量演示
int demo::static_int = 0;

//静态成员函数演示（仅能操作静态成员变量）
template <class T>
static void demo::change_static_var(int static_value);
{ 
	static_int = static_value;
}



//main.cpp
#include "demo.h"
int main()
{
	demo<int> d1(20, 30);
	demo<int> d2 = d1;
	demo::change_static_var(1);
	return 0;
}
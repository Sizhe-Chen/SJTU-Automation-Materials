from copy import deepcopy
from itertools import count
import time
from random import random
C = count(1)
current_time = time.time()


def hanoi(n, start, mid, finish):
    if n == 1: print(start, '->', finish)
    else: 
        hanoi(n-1, start, finish, mid)
        print(start, '->', finish)
        hanoi(n-1, mid, start, finish)
    # hanoi(3, 1, 2, 3)


def fp(s, app):
    if len(s) == 1: print(app + s)
    else:
        for c in s:
            fp(s.replace(c, ''), app + c)
    # fp('abcd', '')


def is_valid(square, i, j):
    n = len(square)
    def valid_index(tmp): return tmp >= 0 and tmp <= n-1
    def search(x_change, y_change):
        x, y = i + x_change, j + y_change
        while valid_index(x) and valid_index(y):
            if square[x][y]: return False
            x, y = x + x_change, y + y_change
        return True

    xys = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]]
    for x_change, y_change in xys:
        if not search(x_change, y_change): return False
    return True

def print_square(square):
    global current_time
    print('-'*(len(square)*2-1))
    print('No.'+str(next(C)), ' Time', round((time.time()-current_time)*1000))
    print('-'*(len(square)*2-1))
    current_time = time.time()
    
    for row in square:
        for item in row:
            if item: print('Q ', end='')
            else: print('* ', end='')
        print()
    print()

def queen_sub(square, k):
    n = len(square)
    for i in range(n):
        tem_square = deepcopy(square)
        tem_square[i][k] = True
        if is_valid(tem_square, i, k):
            if k == n-1: print_square(tem_square)
            else: queen_sub(tem_square, k+1)

def queen(n):
    square = []
    for _ in range(n):
        ls = []
        for _ in range(n):
            ls.append(False)
        square.append(ls)
    queen_sub(square, 0)
    # queen(8)


def is_valid_book(square, i, j):
    n = len(square)
    def valid_index(tmp): return tmp >= 0 and tmp <= n-1
    def search(x_change, y_change):
        x, y = i + x_change, j + y_change
        while valid_index(x) and valid_index(y):
            if square[x][y]: return False
            x, y = x + x_change, y + y_change
        return True

    xys = [[1, 0], [-1, 0], [0, 1], [0, -1]]
    for x_change, y_change in xys:
        if not search(x_change, y_change): return False
    return True

def book_sub(square, like, k):
    n = len(like)
    for i in range(n):
        if not like[i][k]: continue
        tmp_square = deepcopy(square)
        tmp_square[i][k] = True
        if is_valid_book(tmp_square, i, k):
            if k == n-1: print_square(tmp_square)
            else: book_sub(tmp_square, like, k+1)

def book(n): 
    square, like = [], []
    for _ in range(n):
        ls, ls_like = [], []
        for _ in range(n):
            ls.append(False)
            ls_like.append(bool(int(random()*3)))
        square.append(ls)
        like.append(ls_like)
    print_square(like)
    print('\n\n')
    book_sub(square, like, 0)
    # book(5)


def joseph_ring(n, loop=3):
    nexts = {}
    for i in range(n): nexts[i] = (i+1)%n
    lost = 0
    member = 0
    while lost < n-1:
        for i in range(loop-2): member = nexts[member]
        changed_member = member
        member = nexts[member]
        deleted_member = nexts.pop(member)
        nexts[changed_member] = deleted_member
        print(member, end='')
        member = deleted_member
        lost += 1
    print()
    print('Remaining Member', list(nexts.keys())[0])
    # joseph_ring(5)


def swap(a, b): return b, a

def choice_sort(s):
    for i in range(len(s)):
        minimum, index = 100, -1
        for j in range(i, len(s)):
            if s[j] < minimum: 
                minimum, index = s[j], j
        s[i], s[index] = swap(s[i], s[index])
    return s

def insert_sort(s):
    for i in range(len(s)):
        for j in range(i, 0, -1): 
            if s[j] > s[j-1]: break
            s[j], s[j-1] = swap(s[j], s[j-1])
    return s

def bubble_sort(s):
    for i in range(len(s), 0, -1):
        for j in range(0, i-1):
            if s[j] > s[j+1]:
                s[j], s[j+1] = swap(s[j], s[j+1])
    return s

def shell_sort(s):
    div = len(s)
    while div != 1:
        div = div // 2
        for i in range(div):
            k = i
            while k < len(s):
                minimum, index = 100, -1
                j = k
                while j < len(s):
                    if s[j] < minimum: 
                        minimum, index = s[j], j
                    j += div
                s[k], s[index] = swap(s[k], s[index])
                k += div
    return s

def quick_sort(s):
    if len(s) < 2: return s
    left = [x for x in s[1:] if x < s[0]]
    right = [x for x in s[1:] if x >= s[0]]
    return quick_sort(left) + [s[0]] + quick_sort(right)

def merge(s1, s2):
    s = []
    i1, i2 = 0, 0
    while i1 != len(s1) or i2 != len(s2):
        if i1 == len(s1):
            s += s2[i2:]
            break
        elif i2 == len(s2):
            s += s1[i1:]
            break
        elif s1[i1] < s2[i2]:
            s.append(s1[i1])
            i1 += 1
        elif s1[i1] >= s2[i2]:
            s.append(s2[i2])
            i2 += 1
    return s

def merge_sort(s): 
    if len(s) < 2: return s
    return merge(merge_sort(s[:len(s)//2]), merge_sort(s[len(s)//2:]))

def sort(s):
    for sort_method in [choice_sort, insert_sort, shell_sort, quick_sort, merge_sort]:
        print(sort_method(s))
    # sort([9, 4, 6, 3, 7, 5, 8, 0, 1, 2])


if __name__ == "__main__":
    pass